﻿using System.ComponentModel.DataAnnotations;

namespace LaborProductivity.Models
{
    // Model yang digunakan khusus untuk form edit user
    public class EditUserViewModel
    {
        // ID user yang sedang diedit
        public int Id { get; set; }

        // Email user
        [Required(ErrorMessage = "Email wajib diisi.")]
        [EmailAddress(ErrorMessage = "Format email tidak valid.")]
        [MaxLength(255)]
        public string Email { get; set; } = string.Empty;

        // Role user
        [Required(ErrorMessage = "Role wajib dipilih.")]
        public string Role { get; set; } = string.Empty;

        // Status user
        [Required(ErrorMessage = "Status wajib dipilih.")]
        public string Status { get; set; } = "active";
    }
}