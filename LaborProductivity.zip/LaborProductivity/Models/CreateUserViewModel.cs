﻿using System.ComponentModel.DataAnnotations;

namespace LaborProductivity.Models
{
    // Model yang digunakan khusus untuk form tambah user
    public class CreateUserViewModel
    {
        // Email user baru
        [Required(ErrorMessage = "Email wajib diisi.")]
        [EmailAddress(ErrorMessage = "Format email tidak valid.")]
        [MaxLength(255)]
        public string Email { get; set; } = string.Empty;

        // Password user baru
        [Required(ErrorMessage = "Password wajib diisi.")]
        [MinLength(6, ErrorMessage = "Password minimal 6 karakter.")]
        public string Password { get; set; } = string.Empty;

        // Role user baru
        [Required(ErrorMessage = "Role wajib dipilih.")]
        public string Role { get; set; } = string.Empty;

        // Status user baru
        [Required(ErrorMessage = "Status wajib dipilih.")]
        public string Status { get; set; } = "active";
    }
}