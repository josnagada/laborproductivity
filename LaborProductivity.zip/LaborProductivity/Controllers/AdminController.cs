﻿using LaborProductivity.Data;
using LaborProductivity.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LaborProductivity.Controllers
{
    // Hanya user dengan role admin yang boleh mengakses controller ini
    [Authorize(Roles = "admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Menampilkan halaman utama Admin Panel
        // Menampilkan halaman utama Admin Panel
        public async Task<IActionResult> Index()
        {
            // Menghitung jumlah seluruh user yang ada di database
            var totalUsers = await _context.Users.CountAsync();

            // Mengirim jumlah user ke halaman Dashboard
            ViewBag.TotalUsers = totalUsers;

            return View();
        }

        // Menampilkan daftar user dari database
        public async Task<IActionResult> Users()
        {
            var users = await _context.Users
                .OrderBy(user => user.Id)
                .ToListAsync();

            return View(users);
        }
        // Menampilkan form untuk menambah user baru
        [HttpGet]
        public IActionResult CreateUser()
        {
            return View();
        }

        // Menampilkan form untuk mengedit user
        [HttpGet]
        public async Task<IActionResult> EditUser(int id)
        {
            // Mencari user berdasarkan ID
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == id);

            // Jika user tidak ditemukan
            if (user == null)
            {
                return NotFound();
            }

            // Memindahkan data User ke ViewModel EditUser
            var model = new EditUserViewModel
            {
                Id = user.Id,
                Email = user.Email,
                Role = user.Role,
                Status = user.Status
            };

            return View(model);
        }

        // Memproses perubahan data user
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUser(EditUserViewModel model)
        {
            // Memeriksa apakah data dari form valid
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Mencari user berdasarkan ID
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == model.Id);

            // Jika user tidak ditemukan
            if (user == null)
            {
                return NotFound();
            }

            // Memperbarui data user
            user.Email = model.Email;
            user.Role = model.Role;
            user.Status = model.Status;

            // Menyimpan perubahan ke database
            await _context.SaveChangesAsync();

            // Kembali ke daftar user setelah berhasil
            return RedirectToAction(nameof(Users));
        }

        // Menghapus user dari database
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteUser(int id)
        {
            // Mencari user berdasarkan ID
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == id);

            // Jika user tidak ditemukan
            if (user == null)
            {
                return NotFound();
            }

            // Mencegah akun Admin dihapus
            if (user.Role == "admin")
            {
                return BadRequest("Akun Admin tidak dapat dihapus.");
            }

            _context.Users.Remove(user);

            await _context.SaveChangesAsync();

            // Menyimpan pesan sukses sementara untuk ditampilkan di halaman berikutnya
            TempData["SuccessMessage"] = "User berhasil dihapus.";

            // Kembali ke halaman User Management
            return RedirectToAction(nameof(Users));
        }

        // Memproses form untuk menambah user baru
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser(CreateUserViewModel model)
        {
            // Memeriksa apakah data dari form valid
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Memeriksa apakah email sudah digunakan
            var emailSudahAda = await _context.Users
                .AnyAsync(user => user.Email == model.Email);

            if (emailSudahAda)
            {
                ModelState.AddModelError(
                    "Email",
                    "Email tersebut sudah digunakan.");

                return View(model);
            }

            // Membuat objek User baru
            var userBaru = new User
            {
                Email = model.Email,
                Role = model.Role,
                Status = model.Status
            };

            // Membuat password hash sebelum disimpan ke database
            var passwordHasher = new PasswordHasher<User>();

            userBaru.Password = passwordHasher.HashPassword(
                userBaru,
                model.Password);

            // Menambahkan user baru ke database
            _context.Users.Add(userBaru);

            await _context.SaveChangesAsync();

            // Kembali ke halaman daftar user setelah berhasil disimpan
            return RedirectToAction(nameof(Users));
        }
    }
}