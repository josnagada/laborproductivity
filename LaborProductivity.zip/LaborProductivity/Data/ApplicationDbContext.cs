﻿using LaborProductivity.Models;
using Microsoft.EntityFrameworkCore;

namespace LaborProductivity.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(
            DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Hubungkan model User dengan tabel User di database
        public DbSet<User> Users { get; set; }
    }
}